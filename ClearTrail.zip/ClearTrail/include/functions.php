<?php
//echo 'helllloooooooo Prathak';
function theme_styles()  
{ 
	wp_enqueue_style( 'custom', REGISTRATION_PLUGIN_URL . 'css/custommain.css' );
    wp_enqueue_style( 'custom' );
	
	wp_register_script( 'custom1', REGISTRATION_PLUGIN_URL . 'js/custommain.js', true );
    wp_enqueue_script( 'custom1' );
}
add_action('wp_enqueue_scripts', 'theme_styles');

function plugin_admin_menu(){
	add_menu_page('Page title', 'Prathak_Menu', 'manage_options', 'menu_slug', 'myform'); 
}
add_action('admin_menu', 'plugin_admin_menu');

/* Filter the single_template with our custom function*/
function my_custom_template($single) {
    global $post;
    /* Checks for single template by post type */
    if ( $post->post_type == 'prathak' ) {
        if ( file_exists( REGISTRATION_PLUGIN_URL_AB.'/template/custom_single.php' ) ) {
            return REGISTRATION_PLUGIN_URL_AB.'/template/custom_single.php';
        }
    }
    return $single;
}
add_filter('single_template', 'my_custom_template');

function myform(){
	echo do_shortcode('[UploadForm]');
}

require( REGISTRATION_PLUGIN_URL_AB. '/include/shortcode.php');
require( REGISTRATION_PLUGIN_URL_AB. '/include/uploadfile.php');
?>