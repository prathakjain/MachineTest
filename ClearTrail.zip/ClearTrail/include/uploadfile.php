<?php 
require_once(ABSPATH .'/wp-admin/includes/file.php');
//require_once( REGISTRATION_PLUGIN_URL_AB. '/include/common.php');
class UploadFile {
	public static $msg_pass = "";
	public static $uploadUrl = REGISTRATION_PLUGIN_URL_AB."/upload/";
	public static $uploadSampleUrl = REGISTRATION_PLUGIN_URL_AB."/upload/sample/";
	public $unZipUrl = REGISTRATION_PLUGIN_URL_AB."/upload/unzip/";

	function __construct() { 
		
    }

	public function Upload_File() {		
		require( REGISTRATION_PLUGIN_URL_AB. '/template/upload_file.php');
	}

	function Scan($dir) {
	    $tree = glob(rtrim($dir, '/') . '/*/**');
	    if (is_array($tree)) {
	        foreach($tree as $file) {
	            $result[] =  $file;
	        }
	        if(!empty($result)){
	        	foreach($result as $result1){
		        	$ext = pathinfo($result1, PATHINFO_EXTENSION);
	                if($ext === "meta"){  
	            		$results[] = $file;
	                }
	        	}
	        }
	        return $results;
	    }
	} 

	function Upload_Form_Handle(){ 
		$class = new UploadFile();
		// WP_Filesystem();
		if(isset($_POST['uploadzip'])){
			$filename = time().$_FILES['fileupload']['name']; 
			$fileTempName = $_FILES['fileupload']['tmp_name'];
			$ext = pathinfo($filename, PATHINFO_EXTENSION);
			// $result = wp_check_filetype("$filename");			
			if($filename != "" && $ext === 'sample') {
				// Sample File Upload
				$fileLocation =  self::$uploadSampleUrl.$filename;
				$uploadfile = move_uploaded_file($fileTempName, $fileLocation); 
				// Convert Sample File to Zip and Upload
				$fileLocationZip =  self::$uploadUrl.$filename.'.zip';
				copy($fileLocation, $fileLocationZip); 
				$zip = new ZipArchive;
				$res = $zip->open($fileLocationZip);
				if ($res === TRUE) { 
				  if($zip->extractTo($class->unZipUrl)){
				  	$zip->close();
				  	unlink($fileLocationZip);
				  	$getFiles = $class->Scan($class->unZipUrl);
				 	// $getFiles = $this->recursiveScan1(self::$unZipUrl);
				 	if(!empty($getFiles)){
				 		$jsonPath = $getFiles[0];

	//File read And insert in post
	$slices = json_decode(file_get_contents($jsonPath),true);
	for($i=0; $i<count($slices); $i++){  
        $ser_batters = maybe_serialize($slices[$i]['batters']);
        $ser_toppings = maybe_serialize($slices[$i]['topping']);
        $my_post = array(
		    'post_title'    => $slices[$i]['name'],
		    'post_content'  => $slices[$i]['type'],
		    'post_status'   => 'publish',
		    'post_author'   => 1,
		    'post_type' => 'prathak',
	    );
     	$post_id = wp_insert_post( $my_post, true );
	    if ( is_wp_error( $post_id ) ) {
	        self::$msg_pass="Have some issue in our server please try after some time.". is_wp_error( $post_id );
	    } else {
	    	$fileLoc = plugin_dir_url( __DIR__).'upload/sample/'.$filename;
	        add_post_meta($post_id, 'id', $slices[$i]['id'], true);
	        add_post_meta($post_id, 'ppu', $slices[$i]['ppu'], true);
	        add_post_meta($post_id, 'batters', $ser_batters, true);
	        add_post_meta($post_id, 'topping', $ser_toppings, true);
	        add_post_meta($post_id, 'fileLocation', $fileLoc, true); 
	        self::$msg_pass="Upload Successfully. Please check data on front end.";
	    }
	}
	

	// array_map( 'unlink', array_filter((array) glob($class->unZipUrl."/*") ) );

				 	} else {
				 		self::$msg_pass="Not finding (.meta) extantion file in Root directory please see dummy Zip file";
				 	}

				  }
				} else {
				   self::$msg_pass="There was an error unzipping the file.";
				} 
			} else {
				self::$msg_pass="Please Select File with (.sample) extantion";
			}
		} 		
	}

	public function msg_passing_uploadfile_print(){
		echo self::$msg_pass;
	}	

}
add_shortcode( 'UploadForm', array( 'UploadFile', 'Upload_File' ) );
add_action( 'init', array( 'UploadFile', 'Upload_Form_Handle' ) );
add_action('uploadfile_msg',array( 'UploadFile','msg_passing_uploadfile_print'));
?>