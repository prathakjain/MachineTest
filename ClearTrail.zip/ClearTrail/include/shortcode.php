<?php

class ListingPage{
	public static $msg_pass = "Please Fill the Form";
	
	public static function Listing_Form() {		
		require( REGISTRATION_PLUGIN_URL_AB. '/template/listing_page.php');
	}
	public static function Form_Handle(){
		 
		
	}
	public static function msg_passing_list_print(){
		echo self::$msg_pass;
	}	
}
add_shortcode( 'ListView', array( 'ListingPage', 'Listing_Form' ) );
add_action( 'init', array( 'ListingPage', 'Form_Handle' ) );
add_action('listing_msg',array( 'ListingPage','msg_passing_list_print'));
?>