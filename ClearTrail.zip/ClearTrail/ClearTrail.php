 <?php
 /*
 * Plugin Name: Prathak Plugin
 * Author: Prathak Jain
 * Version: Last
 * Description: Machine Test by Clear-trail indore
 */
 ob_start();
 if(!defined('REGISTRATION_PLUGIN_URL')) {
	define('REGISTRATION_PLUGIN_URL', plugin_dir_url( __FILE__ ));
 }	

 if(!defined('REGISTRATION_PLUGIN_URL_AB')) {
	define('REGISTRATION_PLUGIN_URL_AB',  dirname(__FILE__));
 }
 require( REGISTRATION_PLUGIN_URL_AB. '/include/functions.php' );
 
 register_activation_hook( __FILE__, 'registration_plugin_active' );
 register_deactivation_hook( __FILE__, 'registration_plugin_deactivate' );
 /**
 * Plugin Active Create a Page with A short code for listing
 */
 function registration_plugin_active(){
	 $post = array(
      'comment_status' => 'closed',
      'ping_status' =>  'closed' ,
      'post_author' => 1,
      'post_date' => date('Y-m-d H:i:s'),
      'post_name' => 'prathakpj',
      'post_status' => 'publish' ,
      'post_title' => 'Prathak List',
      'post_type' => 'page',
		  'post_content' => '[ListView]',
    );
    $newvalue = wp_insert_post( $post, false );
    update_option( 'hclpage', $newvalue );
 }
 /**
 * Trash Page when plugin is Deactivated
 */
 function registration_plugin_deactivate(){
	$the_page_id = get_option( 'hclpage' ); 
	if( $the_page_id ) {
		wp_delete_post( $the_page_id ); // it will go to trash, not permanent delete 
	}
 }
 /**
 * Plugin Active Create a POST type
 */
 register_activation_hook( __FILE__, 'create_post_type');
 add_action( 'init', 'create_post_type' );
 function create_post_type() {
    register_post_type( 'prathak',
      array(
        'labels' => array(
          'name' => __( 'Prathaks' ),
          'singular_name' => __( 'Prathak' )
        ),
        'public' => true,
        'has_archive' => true,
        'rewrite' => array("slug" => "prathaks"),
        'supports' => array ('title', 'editor', 'comments', 'excerpt', 'custom-fields', 'thumbnail'),
        // 'taxonomies' => array('category'),
      )
    );
 }
 add_theme_support('post-thumbnails'); 
 ?>