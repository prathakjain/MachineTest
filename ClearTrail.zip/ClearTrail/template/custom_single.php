<?php
 /**
 * Prathak single custom post type template
 */
 	get_header();
 ?>


	<div id="primary" class="content-area">
		<main id="main" class="site-main" style="text-align: center;">

			<?php 
                // Start the Loop.
                while ( have_posts() ) : the_post(); 

                	$fileLocation = get_post_meta(get_the_ID(), 'fileLocation', true ) ;
                	$id = get_post_meta(get_the_ID(), 'id', true ) ;  
                	$ppu = get_post_meta(get_the_ID(), 'ppu', true ) ; 
                	$batters = maybe_unserialize(get_post_meta(get_the_ID(), 'batters', true ));
                	$topping = maybe_unserialize(get_post_meta(get_the_ID(), 'topping', true ));





                	?>
                		<h4>Basic Info</h4>
						<table> 
						  <tr> <th>Name</th> <td><?php echo the_title();?></td> </tr>
						  <tr> <th>Type</th> <td><?php echo the_content();?></td> </tr>
						  <tr> <th>id</th> <td><?php echo $id;?></td> </tr> 
						  <tr> <th>ppu</th> <td><?php echo $ppu;?></td> </tr> 
						</table>
<?php
if(!empty($batters)){
	echo '<h4>Batters</h4>';
	echo "<table>";
	foreach($batters as $batters1){ 
		if(is_array($batters1)){
			foreach($batters1 as $batters12){ ?>
				<tr> <th><?= $batters12['id']; ?></th> <td><?= $batters12['type']; ?></td> </tr> 
				<?php
			}
		}
	}
	echo "</table>";
} 
if(!empty($topping)){
	echo '<h4>Topping</h4>';
	echo "<table>";
	foreach($topping as $topping1){  ?>
		<tr> <th><?= $topping1['id']; ?></th> <td><?= $topping1['type']; ?></td> </tr>
	<?php }
	echo "</table>";
}
?>  
						
	<a class="pjbtnn" href="<?= $fileLocation; ?>" target="_blank">Download</a>
                	<?php 
                endwhile;
			 
			?>

	<br /> <br /> <br /> <br />
		</main><!-- #main -->
	</div><!-- #primary -->

 <?php
 	get_footer();
 ?>