<h1>
	<?php do_action('uploadfile_msg'); ?>
</h1>
<h4>Upload File</h4>
<form action="" method="POST" enctype="multipart/form-data"> 
	<input type="file" name="fileupload" required="" /> 
	<input type="Submit" name="uploadzip" value="Upload File" />
</form>