<div id="primary" class="content-area">
		<main id="main" class="site-main">
 

 <?php
 
$currentPage = get_query_var('paged');
 
 
// General arguments
 
$posts = new WP_Query(array(
    'post_type' => 'prathak', // Default or custom post type
    'posts_per_page' => 2, // Max number of posts per page 
    'paged' => $currentPage
));  
// Content display
 
if ($posts->have_posts()) :
    while ($posts->have_posts()) :
        $posts->the_post(); ?>

        <div class='post-wrap'>
        <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
            <div class="post-excerpt">
                <?php the_excerpt(); ?>
            </div>
            <a class="button" href="<?php the_permalink(); ?>">Read More</a>
    	</div>
        <?php 
    endwhile;
    else :
    _e( 'Sorry, no posts were found.', 'textdomain' );
endif;
 
 
// Bottom pagination (pagination arguments)
 
echo "<div class='page-nav-container prathakpagination'>" . paginate_links(array(
    'total' => $posts->max_num_pages,
    'prev_text' => __('<'),
    'next_text' => __('>')
)) . "</div>";
 
?>

</div>

</main><!-- #main -->
	</div><!-- #primary -->