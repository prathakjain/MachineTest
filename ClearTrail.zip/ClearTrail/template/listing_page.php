<div id="primary" class="content-area">
		<main id="main" class="site-main">

<?php $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
		$loop = array(	'paged' => $paged,
				'posts_per_page' => 3,
				'post_type' => 'prathak'
			);
?>
<?php $pj = new WP_Query($loop);?> 
<?php if ($pj->have_posts()) : while ($pj-> have_posts() ) : $pj->the_post(); ?>
<div><h3><a href="#"><?php the_title();?></a></h3></div>
<?php the_excerpt(); ?>    <a class="button" href="<?php the_permalink(); ?>">Read More</a>
<br/>


<?php endwhile; else: echo 'No Record Found'; endif; ?>


<?php
the_posts_pagination( array(
				'prev_text'          => __( 'Previous page', 'twentytwenty' ),
				'next_text'          => __( 'Next page', 'twentytwenty' ),
				'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'twentytwenty' ) . ' </span>' 	
) ); ?>



</div>

</main><!-- #main -->
	</div><!-- #primary -->